package program3solution;

import java.util.Scanner;

public class Bank{
	 Scanner sc=new Scanner(System.in);
 public void deposite(){
	 System.out.println("Enter Amount");
	 double amount=sc.nextDouble();
	 if(amount>=0) {
		 System.out.println("Amount is Creadited....");
	 }else {
		 System.out.println("Amount is negative....");
	 }
 }
 public static void main(String[] args) {
	Bank obj=new Bank();
	obj.deposite();
	}
}
