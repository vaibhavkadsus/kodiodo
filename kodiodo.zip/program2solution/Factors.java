package program2solution;

import java.util.Scanner;

public class Factors {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number");
		int n=sc.nextInt();
		int fact=1;
		int count;
			for(int i=1;i<=n;i++) {
				fact=fact/i;		
		}
		System.out.println(fact);
	}

	}


