package program1solution;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import maphashmap.Patient;

public class Test1 {

	public static void main(String[] args) {
		Department e1=new Department(101,"Ravi",120000);
		Department e2=new Department(102,"Raj",130000);
		Department e3=new Department(103,"Ram",1450000);
		Map<Integer,Department>m=new HashMap<>();
		m.put(101, e1);
		m.put(102, e2);
		m.put(103, e3);
		List<Map<Integer,Department>>dept1=new ArrayList<>();
		dept1.add(m);
		List<Map<Integer,Department>>dept2=new ArrayList<>();
		dept2.add(m);
		List<Map<Integer,Department>>dept3=new ArrayList<>();
		dept3.add(m);
		System.out.println("Department First: ");
		dept1.forEach((i)->System.out.println(i));
		System.out.println("Department Second");
		dept2.forEach((i)->System.out.println(i));
		System.out.println("Department Third");
		dept3.forEach((i)->System.out.println(i));
		
	}

}
