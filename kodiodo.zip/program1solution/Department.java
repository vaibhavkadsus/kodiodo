package program1solution;

public class Department {
	int id;
	String name;
	double salary;
	public Department(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
}
